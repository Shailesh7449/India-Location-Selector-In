const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "prajju@2003",
  database: "india_data"
});

db.connect(err => {
  if (err) {
    console.error("DB Error:", err);
  } else {
    console.log("MySQL Connected");
  }
});

// ROOT API
app.get("/", (req, res) => {
  res.send("API Running");
});

// STATES API
app.get("/states", (req, res) => {
  db.query("SELECT * FROM states", (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Server error" });
    }
    res.json(result);
  });
});

// DISTRICTS API
app.get("/districts/:state_id", (req, res) => {
  db.query(
    "SELECT * FROM districts WHERE state_id = ?",
    [req.params.state_id],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Server error" });
      }
      res.json(result);
    }
  );
});

// SUBDISTRICTS API
app.get("/subdistricts/:district_id", (req, res) => {
  db.query(
    "SELECT * FROM subdistricts WHERE district_id = ?",
    [req.params.district_id],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Server error" });
      }
      res.json(result);
    }
  );
});

// VILLAGES API (LIMIT added )
app.get("/villages/:subdistrict_id", (req, res) => {
  db.query(
    "SELECT * FROM villages WHERE subdistrict_id = ? LIMIT 100",
    [req.params.subdistrict_id],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Server error" });
      }
      res.json(result);
    }
  );
});

// SEARCH API (Hierarchical & Secure)
app.get("/search", (req, res) => {
  const { q, subdistrict_id } = req.query;
  const searchTerm = `%${q}%`;

  let query = `
    SELECT v.village, v.village_id, v.subdistrict_id, s.subdistrict, d.district, st.state
    FROM villages v
    JOIN subdistricts s ON v.subdistrict_id = s.subdistrict_id
    JOIN districts d ON s.district_id = d.district_id
    JOIN states st ON d.state_id = st.state_id
    WHERE v.village LIKE ?
  `;
  const params = [searchTerm];

  if (subdistrict_id) {
    query += " AND v.subdistrict_id = ?";
    params.push(subdistrict_id);
  }

  query += " LIMIT 50";

  db.query(query, params, (err, result) => {
    if (err) {
      console.error("Search Error:", err);
      return res.status(500).json({ error: "Server error" });
    }
    res.json(result);
  });
});


// FULL HIERARCHY API
app.get("/full/:village_id", (req, res) => {
  db.query(
    `SELECT v.village, s.subdistrict, d.district, st.state
     FROM villages v
     JOIN subdistricts s ON v.subdistrict_id = s.subdistrict_id
     JOIN districts d ON s.district_id = d.district_id
     JOIN states st ON d.state_id = st.state_id
     WHERE v.village_id = ?`,
    [req.params.village_id],
    (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Server error" });
      }
      res.json(result);
    }
  );
});

// START SERVER
app.listen(3000, () => {
  console.log("Server running on port 3000");
});